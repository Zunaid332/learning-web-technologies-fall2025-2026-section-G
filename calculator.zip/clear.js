function clearDisplay() {
    document.getElementById("display").value = "";
}
