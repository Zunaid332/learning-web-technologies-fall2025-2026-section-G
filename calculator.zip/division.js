function divide(a, b) {
    if (b === 0) {
        alert("Cannot divide by zero");
        return 0;
    }
    return a / b;
}
